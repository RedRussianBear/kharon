from .devices import Device


# put your OS-side code here!

def main():
    pass
