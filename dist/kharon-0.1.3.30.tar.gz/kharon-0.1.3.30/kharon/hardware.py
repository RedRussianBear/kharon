# LED, Analog_Pin, Digital_pin, Switch, Pushbutton


class Hardware:
    c = ''

    def __init__(self):
        pass

    def declaration(self, name):
        pass

    def setup(self, name):
        pass


class AnalogPin(Hardware):
    c = ''


class DigitalPin(Hardware):
    c = ''


class Led(Hardware):
    c = ''


class Switch(Hardware):
    c = ''


class Button(Hardware):
    c = ''
