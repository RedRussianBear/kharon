# LED, Analog_Pin, Digital_pin, Switch, Pushbutton


class Hardware:
    def c(self):
        pass


class Led(Hardware):
    def c(self):
        pass


class AnalogPin(Hardware):
    def to_string(self):
        pass


class DigitalPin(Hardware):
    def c(self):
        pass


class Switch(Hardware):
    def c(self):
        pass


class Button(Hardware):
    def c(self):
        pass
