import devices

main()