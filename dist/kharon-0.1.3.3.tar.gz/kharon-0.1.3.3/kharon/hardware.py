# LED, Analog_Pin, Digital_pin, Switch, Pushbutton


class Hardware:
    def to_c_string(self):
        pass


class Led(Hardware):
    def to_c_string(self):
        pass


class AnalogPin(Hardware):
    def to_string(self):
        pass


class DigitalPin(Hardware):
    def to_c_string(self):
        pass


class Switch(Hardware):
    def to_c_string(self):
        pass


class Button(Hardware):
    def to_c_string(self):
        pass
