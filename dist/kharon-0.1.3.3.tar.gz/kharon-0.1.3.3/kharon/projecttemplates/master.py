import devices

main()