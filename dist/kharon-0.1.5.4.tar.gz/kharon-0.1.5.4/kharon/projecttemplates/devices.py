from kharon import hardware
from kharon.vars import Int, Void, returns, parameter_types

# put your devices here


class Device:
    # members, eg hardware and global variables

    # and functions
    # remember to add @returns(Type) and @returns(Type, Type, ...)
    pass
